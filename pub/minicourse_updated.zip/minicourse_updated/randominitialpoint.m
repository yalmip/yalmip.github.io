function x = randominitialpoint

% Create point in box, but not on red squares
x = [randn;-2+4*rand(1);randn;-2+4*rand];
while norm(x([2;4])+[0.3;0],inf)<0.2 | norm(x([2;4])+[-.2;0.3],inf)<0.2
    x = [randn;-2+4*rand(1);randn;-2+4*rand];
end
% Make sure it doesn't point outward
x(1) = -.1*abs(x(1))*sign(x(2));
x(3) = -.1*abs(x(3))*sign(x(4));

