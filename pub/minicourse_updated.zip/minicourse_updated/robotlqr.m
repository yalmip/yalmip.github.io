load data_ex_robot

% Loads A B C in x(k+1) = A*x + B*u, y = Cx
% x1 = x velocity
% x2 = x position
% x3 = y position
% x4 = y position

% LQR controller 
% (don't mind the details, we just need some initial controller)
Q = eye(2);
R = .1*eye(2);
L = dlqry(A,B,C,zeros(2,2),Q,R);

% Plot the playing field and regions to avoid. As avid YALMIP users, we use
% YALMIP to plot a couple of squares. We will use these later
clf
dummy = sdpvar(2,1);
plot(-2 <= dummy <= 2,[],'g');hold on
plot(norm(dummy+[0.3;0],inf)<=0.2);
plot(norm(dummy+[-.2;0.3],inf)<=0.2);

% Initial state
x_ = randominitialpoint;
% Run a simulation until state has converged
while norm(x_) > 1e-2
    drawrobot(x_);
    % Control computation
    u_ = -L*x_;
    % Time update
    x_ = A*x_+B*u_;
    pause(.01)
end

