function drawcar(x,fig);
switch nargin
    case 1
        plot(x(2),x(4),'*');
        line([x(2);x(2)+x(1)*0.05],[x(4);x(4)+0.05*x(3)]);
    otherwise
        plot(x(2),x(4),fig);
        line([x(2);x(2)+x(1)*0.05],[x(4);x(4)+0.05*x(3)]);        
end
    