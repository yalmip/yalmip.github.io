% Plot the intersection of TH, Q2 and Q3:

% quick way
I = Q & Q2 & Q3

% longer way:
I = Q & Q2;
I = I & Q3;

opts = struct('wire', 1, 'linewidth', 3);
plot(I, 'y');
hold on; plot(Q, 'r', Q1, 'g', Q2, 'b', Q3, 'm', opts); hold off
