clear
close all

robotmpc1;

% prediction model: state-space dynamics
model.A = A;
model.B = B;
model.C = C;
model.D = zeros(2);

% prediction model: constraints
model.umin = [-1; -1];
model.umax = [1; 1];
model.ymin = [-2; -2];
model.ymax = [2; 2];

% optimization problem setup
problem.norm = 2;     % quadratic cost
problem.N = N;        % prediction horizon
problem.R = R;        % penalty on control inputs
problem.Q = C'*Q*C;   % state penalty (well, in this case penalty on outputs)

% construct the controller object
controller = mpt_control(model, problem, 'online');

% closed-loop simulation made by hand

% draw the playing field in a new figure
figure
plot(-2 < C*x{1} < 2,[],'g');hold on
plot(norm(C*x{1}+[0.3;0],inf)<0.2);
plot(norm(C*x{1}+[-.2;0.3],inf)<0.2);

% use the same initial state as in the robotmpc2 demo
x_ = x0;

% Run a simulation until state has converged
while norm(x_) > 1e-2
    drawrobot(x_);
    % obtain control action associated to state x_
    u_ = controller(x_);
    % Time update
    x_ = A*x_+B*u_;
    pause(.01)
end

% closed-loop simulation using MPT's commands:
[X, U, Y] = sim(controller, x0, struct('minnorm', 1e-2));
figure; simplot(controller, x0, struct('minnorm', 1e-2));
