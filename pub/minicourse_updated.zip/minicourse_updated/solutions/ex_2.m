% create a new polytope by shifting all points of the triangle
shift = [0.5; -0.2];
Q1 = Q + shift;
 
% now scale the shifted polytope by a factor of 0.8
Q2 = 0.8*Q1;
 
% finally, rotate Q2 by 45 degrees
th = 45/180*pi; M = [cos(th) -sin(th); sin(th) cos(th)];
Q3 = M*Q2;

% and plot all polytopes in wireframe
opts = struct('wire', 1, 'linewidth', 3);
plot(Q, 'r', Q1, 'g', Q2, 'b', Q3, 'm', opts)
axis equal
