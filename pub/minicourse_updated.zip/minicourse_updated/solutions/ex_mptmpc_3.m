% run ex_2 to load all necessary data

close all

% plot the controller regions
plot(controller_explicit)

% plot the two initial conditions of interest
x1 = [-4; -1];
x2 = [-4; -2];
hold on
plot(x1(1), x1(2), 'kx', x2(1), x2(2), 'ko', 'markersize', 12);

% optimal control action associated to x1
%
% since x1 is contained in one of the regions, 
% we expect a feasible answer
u = controller_explicit(x1)
% check that x1 is indeed in one of the regions
isinside(controller_explicit.Pn, x1)

% optimal control action associated to x2
%
% since x2 is outside of the colored area, 
% there should be no control action associated
% to this state, in which case u = []
u = controller_explicit(x2)
% check that x2 is indeed outside of the regions
isinside(controller_explicit.Pn, x2)

% now plot the feedback laws
close all
plotu(controller_explicit)

% and look at the graph from the top
view(2)
