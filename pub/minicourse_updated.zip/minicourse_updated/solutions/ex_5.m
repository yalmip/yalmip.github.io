% input data
A = [1 1; 0 1]; B = [1; 0.5];
K = dlqr(A, B, eye(2), 1);
xmax = [5; 5]; xmin = [-5; -5];
umax = 1; umin = -1;
I = eye(2);
 
% set of states which satisfy state and input constraints
X = polytope([I; -I], [xmax; -xmin]);
U = polytope([-K; K], [umax; -umin]);
PSI = X & U
 
% plot the set
plot(PSI)

% compute extremal vertices of PSI
E = extreme(PSI);

% check that input and state constraints hold for each vertex
for i = 1:size(E, 1)
    x = E(i, :)';
    u = -K*x;
    if isinside(unitbox(1), u) && isinside(X, x)
        fprintf('Vertex %d OK\n', i);
    else
        fprintf('Constraints violated for vertex %i!\n', i);
    end
end
