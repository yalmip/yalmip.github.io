load data_ex_polytope
clf

xc = sdpvar(2,1);
d = sdpvar(2,1);
sdpvar r
solvesdp([A*(xc+r*d) <= b, d'*d <= 1, uncertain(d)],-r)

x = sdpvar(2,1);
plot(A*x <= b);
hold on
plot(norm(x-double(xc))<double(r),x,'y',100)
