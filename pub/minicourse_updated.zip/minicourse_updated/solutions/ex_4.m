clear
close all

% input data
Xi = unitbox(2) + [3; 0];
Xf = 0.5*unitbox(2);
A = [0.5, -0.75; 0.75, 0.5];
N = 10;

% initialize the data storage
S = Xi;
for k = 1:N
    % compute the set Xk1 = A*Xk
    r = A*S(end);
    % add Xk1 at the end of S
    S = [S r];
end
plot(Xf, 'k', S)


% if a miss, determine the proper N:
N = 0;
S = Xi;
while ~dointersect(S, Xf)
  N = N + 1;
  r = A*S(end);
  S = [S r];
end
plot(Xf, 'k', S);
N
