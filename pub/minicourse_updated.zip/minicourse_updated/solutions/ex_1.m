% Create a polytope {\tt P} as the 2D unit box centered at the origin, i.e.
% $P = {(x_1,~x_2)^T ~|~ -1 \leq x_1 \leq 1,~ -1 \leq x_2 \leq 1}$.
%
% convert all inequalities into the form [a1 a2]*[x1; x2] <= b:
%  x_1      <= 1      i.e. [ 1  0]*[x1; x2] <= 1
% -x_1      <= 1      i.e. [-1  0]*[x1; x2] <= 1
%       x_2 <= 1      i.e. [ 0  1]*[x1; x2] <= 1
%      -x_2 <= 1      i.e. [ 0 -1]*[x1; x2] <= 1
% now stack all inequalities into a matrix:
A = [1 0; -1 0; 0 1; 0 -1];
b = [1; 1; 1; 1];
P = polytope(A, b);

% Create an another polytope {\tt Q} as the convex hull of points $v_1 =
% (-1,~0)^T$, $v_2 = (1,~0)^T$, $v_3 = (0,~1)^T$.
v1 = [-1; 0]; v2 = [1; 0]; v3 = [0; 1];
Q = polytope([v1 v2 v3]');  % don't forget the transpose!

% Plot {\tt P} in red and {\tt Q} in blue (don't forget to use {\tt figure}
% to open a new plot).
figure; plot(P, 'r')
figure; plot(Q, 'b')

% Are the two polytopes equal?
P == Q

% Is {\tt P} a subset of {\tt Q}?
P <= Q

% Is {\tt P} a superset of {\tt Q}?
P >= Q

