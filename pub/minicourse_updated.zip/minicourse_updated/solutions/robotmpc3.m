load data_ex_robot

% Loads A B C in x(k+1) = A*x + B*u, y = Cx
% x1 = x velocity
% x2 = x position
% x3 = y velocity
% x4 = y position

% System dimensions
nu = size(B,2);
nx = size(A,1);

% MPC tuning
Q = eye(2);
R = .1*eye(2);
%At least N=5 is needed, by try different lengths. Don't use unnecessarily
%long prediction horizons as that only leads to more computational effort
N = 5;

u = sdpvar(repmat(nu,1,N),repmat(1,1,N));
x = sdpvar(repmat(nx,1,N+1),repmat(1,1,N+1));

constraints = [];
objective = 0;
for k = 1:N
    % Add stage-cost y'Qy+u'Ru to objective
    objective = objective + norm(C*x{k},1)+norm(R*u{k},1);
    % Add dynamics constraint, x{k+1} == ...
    constraints = [constraints, x{k+1} == A*x{k}+B*u{k}];
    % Add control and output constraints
    constraints = [constraints, -2<=C*x{k}<=2,-1<=u{k}<=1];
    
    % Avoidance constraints
    constraints = [constraints,norm(C*x{k}+[0.3;0],inf)>=0.2,norm(C*x{k}+[-.2;0.3],inf)>=0.2];
end

% Plot the playing field and regions to avoid. 
clf
plot(-2 <= C*x{1} <= 2,[],'g');hold on
plot(norm(C*x{1}+[0.3;0],inf)<=0.2);
plot(norm(C*x{1}+[-.2;0.3],inf)<=0.2);

% Create controller x{1} -> u{1}
controller = optimizer(constraints,objective,[],x{1},u{1});

% Initial state
x_ = randominitialpoint;

% Run a simulation until state has converged
while norm(x_) > 1e-2
    drawrobot(x_);
    
    % Solve with constraints x{1}==x_    
    u_ = controller{x_};
    
    % Time update
    x_ = A*x_+B*u_;
    pause(.01)
end
