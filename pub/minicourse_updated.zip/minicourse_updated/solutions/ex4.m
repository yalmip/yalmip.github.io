solvesdp(C,-(x+y))

D = [x^2<=t,y^2<=s,s^2+t^2<=1]
solvesdp(D,-(x+y))

E = [x^4 + y^4 <= 1]
solvesdp(E,-(x+y))

F = norm([x;y],4) <= 1
solvesdp(F,-(x+y))