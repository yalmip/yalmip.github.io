% input data
A = [1 1; 0 1]; B = [1; 0.5];
K = dlqr(A, B, eye(2), 1);
xmax = [5; 5]; xmin = [-5; -5];
umax = 1; umin = -1;
I = eye(2);
 
% set of states which satisfy state and input constraints
X = polytope([I; -I], [xmax; -xmin]);
U = polytope([-K; K], [umax; -umin]);

% the sets X and U were defined in the previous example
PSI = X & U;
k = 1;
kmax = 10;
while k < kmax
    PSI(k+1) = inv(A-B*K)*PSI(k) & PSI(k);
    k = k + 1;
    if PSI(k) == PSI(k-1), break, end
end
PHI = PSI(end)

% plot all sets
plot(PSI)

% or a one-liner:
PHI = mpt_infset((A-B*K), PSI(1), kmax);
