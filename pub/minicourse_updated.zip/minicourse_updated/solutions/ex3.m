sdpvar x y s t

Constraint1 = [t x;x 1]>=0;
Constraint2 = [s y;y 1]>=0;
Constraint3 = [1 s t;s 1 0;t 0 1]>=0;

C = [Constraint1,Constraint2,Constraint3];
plot(C,[x;y],'r',100)