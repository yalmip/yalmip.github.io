A = randn(15,5);
b = rand(15,1);
x = sdpvar(5,1);

Constraints = [A*x <= b, sum(x)==1];
Objective = x(1) + x(end);
solvesdp(Constraints,Objective)
double(x)