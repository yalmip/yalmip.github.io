x = sdpvar(2,1);
C1 = abs(x)<=1;
C2 = abs(x+[0.5;0])>=0.1;
plot(C1,x,'y');hold on
plot([C1,C2],x,'b');