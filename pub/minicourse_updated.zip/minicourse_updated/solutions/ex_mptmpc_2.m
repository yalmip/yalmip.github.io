clear

% prediction model for the double integrator
model.A = [1, 1; 0, 1];
model.B = [1; 0.5];
model.C = [1 0];
model.D = 0;

% constraints
model.umin = -1;
model.umax = 1;
model.xmin = [-5; -5];
model.xmax = [5; 5];

% objective function
problem.N = 5;
problem.norm = 2;
problem.Q = eye(2);
problem.R = 1;

% on-line controller
controller_online = mpt_control(model, problem, 'online');
% explicit controller
controller_explicit = mpt_control(model, problem, 'explicit');

x0 = [-3; 0];
% timing of the on-line controller
tic;
X = sim(controller_online, x0);
t = toc; 
fprintf('Average execution time of the on-line controller: %f secs\n', ...
    t/size(X, 1))

% timing of the explicit controller
tic;
X = sim(controller_explicit, x0);
t = toc;
fprintf('Average execution time of the explicit controller: %f secs\n', ...
    t/size(X, 1))

