load data_ex_polytope

% Define the variables
x = sdpvar(2,1);

% Inspect the polytopic set
plot(A*x < b);

% Minimize the first coordinate
solvesdp(A*x <= b, x(1)); L(1) = double(x(1));
% Maximize the first coordinate
solvesdp(A*x <= b, -x(1)); U(1) = double(x(1));
% Minimize the first coordinate
solvesdp(A*x <= b, x(2)); L(2) = double(x(2));
% Maximize the first coordinate
solvesdp(A*x <= b, -x(2)); U(2) = double(x(2));

% Plot polytope over bounding box
clf
plot(L(:) <= x <= U(:))
hold on
plot(A*x <= b,x,'y');

text(-0.2,-0.55,'L1')
text(0.36,-0.55,'U1')
text(-0.47,-0.42,'L2')
text(-0.47,0.04,'U2')