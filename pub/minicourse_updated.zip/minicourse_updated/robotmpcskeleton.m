load data_ex_robot

% Loads A B C in x(k+1) = A*x + B*u, y = Cx
% x1 = x velocity
% x2 = x position
% x3 = y velocity
% x4 = y position

% System dimensions
nu = size(B,2);
nx = size(A,1);

% MPC tuning 
Q = eye(2);
R = .1*eye(2);
%At least N=5 is needed, by try different lengths. Don't use unnecessarily
%long prediction horizons as that only leads to more computational effort
N = ...; 

% We set up a general optimization problem for a finite horizon. Note that
% it is entirely independent of the actual current state. Instead, we will
% add a constraint later that the first state element x{1} equals the
% current state. That way, the states x{1},...x{N+1} will be the state
% predictions from the current state if the controls u{1}...u{N} are used

% Quick way to create cells with decision variables
% (we use cells to simplify indexing of vectors with time indicies)
u = sdpvar(repmat(nu,1,N),repmat(1,1,N));
x = sdpvar(repmat(nx,1,N+1),repmat(1,1,N+1));

constraints = [];
objective = 0;
for k = 1:N
    % Add stage-cost y(k)'Qy(k)+u(k)'Ru(k) to objective
    objective = objective + (C*x{k})'*...
    % Add dynamics constraint, x(k+1) = A*x(k)+B*u(k)
    constraints = [constraints, ...];
    % Add control and output constraints
    constraints = [constraints, ];
end

% Plot the playing field and regions to avoid. 
clf
plot(-2 <= C*x{1} <= 2,[],'g');hold on
plot(norm(C*x{1}+[0.3;0],inf)<=0.2);
plot(norm(C*x{1}+[-.2;0.3],inf)<=0.2);

% Initial state
x_ = randominitialpoint;

% Run a simulation until state has converged
while norm(x_) > 1e-2
    drawrobot(x_);
    
    % Solve optimization problem for a particular current state x_ by
    % adding an equality constraint such that x{1} is equal to x_
    solvesdp([constraints, x{1}==],...)
    u_ = double()
    % Time update
    x_ = A*x_+B*u_;
    pause(.01)
end
